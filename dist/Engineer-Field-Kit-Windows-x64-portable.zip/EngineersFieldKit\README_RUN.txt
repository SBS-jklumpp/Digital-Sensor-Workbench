Engineer Field Kit - Windows Portable Build

How to run:
1) Extract this zip.
2) Open the EngineersFieldKit folder.
3) Double-click EngineersFieldKit.exe

No Python installation is required on the target machine.
